export const imageQueries = {
    createImage:`
    INSERT INTO images (gamesId, image) VALUES(?,?)
    `,
    readImages:`
    SELECT imagesId AS imagesId, image AS image, gamesId AS gamesId
    FROM images
    WHERE gamesId = ?
    `,
    updateImage:`
    UPDATE images
    SET image = ?, gamesId = ?
    WHERE imagesId = ?
    `,
}