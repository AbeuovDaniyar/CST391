import {execute} from '../services/mysql.connector';
import {Images} from './images.model';
import {imageQueries} from './images.queries';

export const readImages = async (gameId: number) => {
    return execute<Images[]>(imageQueries.readImages, [gameId]);
};

export const createImage = async (images: Images, index: number, gameId: number) => {
    return execute<Images[]>(imageQueries.createImage, [gameId, images.image]);
};

export const updateImage = async (images: Images, gamesId: number) => {
    return execute<Images[]>(imageQueries.updateImage, [images.image, gamesId, images.imagesId]);
};