import {Images} from '../images/images.model';

export interface Game {
    gamesId: number,
    name: string,
    description: string,
    year: string,
    price: number,
    rating: number,
    images: Images[]
}