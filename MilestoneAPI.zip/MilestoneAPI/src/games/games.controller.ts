import {Request, RequestHandler, Response} from 'express';
import {Game} from './games.model';
import { Images } from '../images/images.model';
import * as GamesDao from './games.dao';
import * as ImagesDao from '../images/images.dao';
import {OkPacket} from 'mysql';

export const readGames: RequestHandler = async (req: Request, res: Response) => {
    try{
        let games = await GamesDao.readGames();
        let gamesId = parseInt(req.query.gamesId as string);

        console.log('gamesId', gamesId);
        if(Number.isNaN(gamesId)){
            games = await GamesDao.readGames();
        } else {
            games = await GamesDao.readGamesByGamesId(gamesId);
        }
        await readImages(games, res);

        res.status(200).json(
            games
        );
    }catch(error){
        console.error('[games.controller][readGames][Error] ', error);
        res.status(500).json({
            message: 'There was error fetching games'
        });
    }
}; 

export const readGamesById: RequestHandler = async (req: Request, res: Response) => {
    try{
        let gamesId = parseInt(req.query.gamesId as string);

        let games = await GamesDao.readGamesByGamesId(gamesId);
        console.log('gamesId', gamesId);
        
        await readImages(games, res);

        res.status(200).json(
            games
        );
    }catch(error){
        console.error('[games.controller][readGamesById][Error] ', error);
        res.status(500).json({
            message: 'There was error fetching games'
        });
    }
}; 

export const readGamesByName: RequestHandler = async (req: Request, res: Response) => {
    try{
        const games = await GamesDao.readGamesByName(req.params.name);

        await readImages(games, res);

        res.status(200).json(
            games
        );

    }catch(error){
        console.error('[games.controller][readGamesByName][Error] ', error);
        res.status(500).json({
            message: 'There was error fetching games'
        });
    }
};

export const readGamesByNameSearch: RequestHandler = async (req: Request, res: Response) => {
    try{
        console.log('search', req.params.search);
        const games = await GamesDao.readGamesByNameSearch('%' + req.params.search + '%');

        await readImages(games, res);

        res.status(200).json(
            games
        );

    }catch(error){
        console.error('[games.controller][readGamesByNameSearch][Error] ', error);
        res.status(500).json({
            message: 'There was error fetching games'
        });
    }
};

export const createGame: RequestHandler = async (req: Request, res: Response) => {
    try{
        const okPacket: OkPacket = await GamesDao.createGame(req.body);

        console.log('req.body', req.body);

        console.log('games', okPacket);

        req.body.images.forEach(async(image: Images, index: number) => {
            try{
                await ImagesDao.createImage(image,index,okPacket.insertId);
            }catch(error){
                console.error('[games.controller][createGameImage][Error] ', error);
                res.status(500).json({
                    message: 'There was error creating game'
                });
            }
        });;

        res.status(200).json(
            okPacket
        );

    }catch(error){
        console.error('[games.controller][createGame][Error] ', error);
        res.status(500).json({
            message: 'There was error creating games'
        });
    }
};

export const updateGame: RequestHandler = async (req: Request, res: Response) => {
    try{
        const okPacket: OkPacket = await GamesDao.updateGame(req.body);

        console.log('req.body', req.body);

        console.log('games', okPacket);

        req.body.images.forEach(async(images: Images) => {
            try{
                await ImagesDao.updateImage(images, req.body.gamesId);
            }catch(error){
                console.error('[games.controller][updateGameImage][Error] ', error);
                res.status(500).json({
                message: 'There was error updating game images'
                });
            }
        });;

        res.status(200).json(
            okPacket
        );

    }catch(error){
        console.error('[games.controller][updateGame][Error] ', error);
        res.status(500).json({
            message: 'There was error updating games'
        });
    }
};

async function readImages(games: Game[], res: Response<any, Record<string, any>>){
    for(let i = 0; i < games.length; i++){
        try{
            const images = await ImagesDao.readImages(games[i].gamesId);
            games[i].images = images;
        }catch(error){
            console.error('[games.controller][readImages][Error] ', error);
            res.status(500).json({
                message: 'There was error fetching images'
            });
        }
    }
};

export const deleteGame: RequestHandler = async (req: Request, res: Response) => {
    try{
        let gamesId = parseInt(req.params.gamesId as string);

        console.log('gamesId', gamesId);

        if(!Number.isNaN(gamesId)){
            const response = await GamesDao.deleteGame(gamesId);

            res.status(200).json(
                response
            );
        }else{
            throw new Error("Integer expected for gamesId");
        }
    }catch(error){
        console.error('[games.controller][deleteGame][Error] ', error);
        res.status(500).json({
            message: 'There was error deleting game'
        });
    }
};