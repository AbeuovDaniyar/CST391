import {OkPacket} from 'mysql';
import {execute} from '../services/mysql.connector';
import {Game} from './games.model';
import {gamesQueries} from './games.queries';

export const readGames = async () => {
    return execute<Game[]>(gamesQueries.readGames, []);
};

export const readGamesByName = async (name: string) => {
    return execute<Game[]>(gamesQueries.readGamesByName, [name]);
};

export const readGamesByNameSearch = async (search: string) => {
    return execute<Game[]>(gamesQueries.readGamesByNameSearch, [search]);
};

export const readGamesByGamesId = async (gamesId: number) => {
    return execute<Game[]>(gamesQueries.readGamesByGamesId, [gamesId]);
};

export const createGame = async (games: Game) => {
    return execute<OkPacket>(gamesQueries.createGame, [games.name, games.description, games.year, games.price, games.rating]);
};

export const updateGame = async (games: Game) => {
    return execute<OkPacket>(gamesQueries.updateGame, [games.name, games.description, games.year, games.price, games.rating, games.gamesId]);
};

export const deleteGame = async (gamesId: number) => {
    return execute<Game[]>(gamesQueries.deleteGame, [gamesId]);
};