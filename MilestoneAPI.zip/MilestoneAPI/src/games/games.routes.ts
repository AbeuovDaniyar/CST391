import {Router} from "express";
import * as GamesController from './games.controller';

const router = Router();
router.
    route('/games').
    get(GamesController.readGames);
router.
    route('/games/:gamesId').
    get(GamesController.readGamesById);
router.
    route('/games/:name').
    get(GamesController.readGamesByName);
router.
    route('/games/search/name/:search').
    get(GamesController.readGamesByNameSearch);
router.
    route('/games').
    post(GamesController.createGame);
router.
    route('/games').
    put(GamesController.updateGame);
router.
    route('/games/:gamesId').
    delete(GamesController.deleteGame);

export default router;

