export const gamesQueries = {
    readGames: `
        SELECT
            gamesId as gamesId, name AS name, description AS description, 
            year AS year, price AS price, rating AS rating
        FROM games 
    `,
    readGamesByName: `
        SELECT
            gamesId as gamesId, name AS name, description AS description, 
            year AS year, price AS price, rating AS rating
        FROM games  
        WHERE games.name = ? 
    `,
    readGamesByNameSearch: `
        SELECT
            gamesId as gamesId, name AS name, description AS description, 
            year AS year, price AS price, rating AS rating
        FROM games  
        WHERE games.name LIKE ?
    `,
    readGamesByGamesId: `
        SELECT
            gamesId as gamesId, name AS name, description AS description, 
            year AS year, price AS price, rating AS rating
        FROM games 
        WHERE gamesId = ? 
    `,
    createGame: `
        INSERT INTO GAMES(name, description, year, price, rating) VALUES (?,?,?,?,?) 
    `,
    updateGame: `
        UPDATE games
        SET name = ?, description = ?, year = ?, price = ?, rating = ?
        WHERE gamesId = ? 
    `,
    deleteGame: `
        DELETE FROM games
        WHERE gamesId = ? 
    `,
}