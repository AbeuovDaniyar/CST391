// Application Dependencies
const { Game } = require('./lib/app/models/Game');
const { Images } = require('./lib/app/models/Images');
const { ProductDAO } = require('./lib/app/database/ProductDAO.js')

const bodyParser = require('body-parser');

// Create instance of an Express Application on Port 3000
const express = require('express');
const app = express();
const port = 3000;

// Database configuration
const dbHost = "localhost"
const dbPort = 3306;
const dbUsername = "root"
const dbPassword = "root"

// Set location of static resources and use the JSON body parser
app.use(express.static('app/images'))
app.use(bodyParser.json());

// Route code begins
// GET Route at Root '/' that returns a Test Text message
app.get('/', function (_req, res)
{
    // Return Test Text
    console.log('In GET / Route');
    res.send('This is the default root Route.');
})
// GET Route at '/games' that returns all Games from the database
app.get('/games', function (_req, res)
{
    // Return Games List as JSON, call ProductDAO.findAllGames(), and return JSON array of Games (a string)
    console.log('In GET /games Route');
    let dao = new ProductDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.findAllGames(function(games)
    {
        res.json(games);
    });
})

// GET Route at '/games'/:name that returns all GAMEs for an images from the database
app.get('/games/:name', function (req, res)
{
    // Return Game List as JSON, call ProductDAO.findGamesByName(), and return JSON array of GAMEs
    console.log('In GET /games Route for ' + req.params.name);
    let dao = new ProductDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.findGamesByName(req.params.name, function(games)
    {
        res.json(games);
    });
})

// GET Route at '/images/:gameId' that returns all Images for the Game.
app.get('/images/:gameId', function (req, res)
{
    // Return Images List as JSON, call ProductDAO.findImagesByGameId(), and return JSON array of Images for the Game.
    let dao = new ProductDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.findImagesByGameId(req.params.gameId, function(images)
    {
        res.json(images);
    });
})

// GET Route at '/games/lastId' that returns last gameId.
app.get('/games_lastId', function (_req, res)
{
    // Return Last Game Id.
    let dao = new ProductDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.getLastGameId(function(lastId)
    {
        res.json(lastId);
    });
})

// GET Route at '/images/lastId' that returns last Image Id.
app.get('/images_lastId', function (_req, res)
{
    // Return Last Image Id.
    let dao = new ProductDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.getLastImageId(function(lastId)
    {
        res.json(lastId);
    });
})



// POST Route at '/games' that adds an GAME and its images to the database
app.post('/games', function (req, res)
{
    console.log(req);
    
    // If invalid POST Body then return 400 response else add Game and Images to the database
    console.log('In POST /games Route with Post of ' + JSON.stringify(req.body));
    
    // Check for valid POST Body.
    if(!req.body.gameId || !req.body.name || !req.body.description || !req.body.price || 
        !req.body.platform || !req.body.type || !req.body.country || !req.body.version || !req.body.key)
    {
        res.status(400).json({error: "Invalid Game Posted"});
    }
    else
    {
        // Create Game object model from Posted Data
        let images = [];
        for(let x=0;x < req.body.images.length;++x)
        {
            console.log('image: ' + req.body.images[x].image);
            images.push(new Images(req.body.images[x].id, req.body.images[x].image, req.body.images[x].gameId));
        }
        let game = new Game(req.body.gameId, req.body.name, images, req.body.description, req.body.price, req.body.platform, req.body.type, req.body.country, req.body.version, req.body.key);

        // Call ProductDAO.create() to create a Game from Posted Data and return an OK response     
        let dao = new ProductDAO(dbHost, dbPort, dbUsername, dbPassword);
        dao.create(game, function(gameId)
        {
            if(gameId == -1)
                res.status(200).json({"error" : "Creating GAME failed"})
            else
                res.status(200).json({"success" : "Creating GAME passed with an GAME ID of " + gameId});
        });     
      }
})

// PUT Route at '/games' that updates the Game and its Images in the database
app.put('/games', function (req, res)
{
    // If invalid PUT Body then return 400 response else update Game and Images to the database
    console.log('In PUT /games Route with Post of ' + JSON.stringify(req.body));
    if(!req.body.gameId || !req.body.name || !req.body.description || !req.body.price || 
        !req.body.platform || !req.body.type || !req.body.country || !req.body.version || !req.body.key)
    {
        // Check for valid PUT Body, note this should validate EVERY field of the POST
        res.status(400).json({error: "Invalid GAME Posted"});
    }
    else
    {
        // Create the GAME object model from Posted Data
        let images = [];
        for(let x=0;x < req.body.images.length;++x)
        {
            images.push(new Images(req.body.images[x].id, req.body.images[x].image, req.body.images[x].gameId));
        }
        let game = new Game(req.body.gameId, req.body.name, images, req.body.description, req.body.price, req.body.platform, req.body.type, req.body.country, req.body.version, req.body.key);

        // Call ProductDAO.update() to update an GAME from Posted Data and return an OK response     
        let dao = new ProductDAO(dbHost, dbPort, dbUsername, dbPassword);
        dao.update(game, function(changes)
        {
            if(changes == 0)
                res.status(200).json({"error" : "Updating GAME passed but nothing was changed"})
            else
                res.status(200).json({"success" : "Updating GAME passed and data was changed"});
        });     
      }
})

// DELETE Route at '/games/:id' that deletes the GAME given an GAME ID from the database
app.delete('/games/:gameId', function (req, res)
{
    // Get the GAME
    console.log('In DELETE /games Route with ID of ' + req.params.gameId);
    let gameId = Number(req.params.gameId);
 
    // Call ProductDAO.delete() to delete an GAME from the database and return if passed
    let dao = new ProductDAO(dbHost, dbPort, dbUsername, dbPassword);
    dao.delete(gameId, function(changes)
    {
        if(changes == 0)
            res.status(200).json({"error" : "Delete GAME failed"})
        else
            res.status(200).json({"success" : "Delete GAME passed"})
    });
 })



// Route code ends
// Start the Server
app.listen(port, () => 
{
    console.log(`Example app listening on port ${port}!`);
});
