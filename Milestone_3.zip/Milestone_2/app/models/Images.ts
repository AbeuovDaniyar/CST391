export class Images
{
    private id: number = 0;
    public image: string = "";
    private gameId: number = 0;

    constructor(id:number, image: string, gameId:number)
    {
        this.id = id;
        this.image = image;
        this.gameId = gameId;
    }

    public get Id(): number {
        return this.id;
    }
    public set Id(value: number) {
        this.id = value;
    }

    public get Image(): string {
        return this.image;
    }
    public set Image(value: string) {
        this.image = value;
    }

    public get GameId(): number {
        return this.gameId;
    }
    public set GameId(value: number) {
        this.gameId = value;
    }

}