import { Images } from "./Images";

export class Game
{
    private gameId: number = 0;
    private name: string = "";
    private images: Images[] = [];
    private description: string = "";
    private price: number = 0;
    private platform: string = "";
    private type: string = "";
    private country: string = "";
    private version: string = "";
    private key: string = "";

    constructor(gameId: number, name:string, images:Images[], description:string, price:number,
        platform: string, type: string, country: string, version: string, key: string)
    {
        this.gameId = gameId;
        this.name = name;
        this.images = images;
        this.description = description;
        this.price = price;
        this.platform = platform;
        this.type = type;
        this.country = country;
        this.version = version;
        this.key = key;
    }

    public get GameId(): number {
        return this.gameId;
    }
    public set GameId(value: number) {
        this.gameId = value;
    }

    public get Name(): string {
        return this.name;
    }
    public set Name(name: string) {
        this.name = name;
    }

    public get Images(): Images[] {
        return this.images;
    }

    public set Images(images: Images[]) {
        this.images = images;
    }

    public get Description(): string {
        return this.description;
    }
    public set Description(description: string) {
        this.description = description;
    }

    public get Price(): number {
        return this.price;
    }
    public set Price(price: number) {
        this.price = price;
    }

    public get Platform(): string {
        return this.platform;
    }
    public set Platform(value: string) {
        this.platform = value;
    }

    public get Type(): string {
        return this.type;
    }
    public set Type(value: string) {
        this.type = value;
    }

    public get Country(): string {
        return this.country;
    }
    public set Country(value: string) {
        this.country = value;
    }

    public get Version(): string {
        return this.version;
    }
    public set Version(value: string) {
        this.version = value;
    }

    public get Key(): string {
        return this.key;
    }
    public set Key(value: string) {
        this.key = value;
    }

}