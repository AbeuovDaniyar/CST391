import { Game } from "../models/Game";
import { Images } from "../models/Images";

import * as mysql from "mysql";
import * as util from "util";

export class ProductDAO
{
    private host:string = "";
    private port:number = 3306;
    private username:string = "";
    private password:string = "";
    private schema:string = "cst-391-milestone";
    private pool = this.initDbConnection();
    
    /**
     * Non-default constructor.
     * 
     * @param host Database Hostname
     * @param username Database Username
     * @param password Database Password
     */
    constructor(host:string, port:number, username:string, password:string)
    {
        this.host = host;
        this.port = port;
        this.username = username;
        this.password = password;
        this.pool = this.initDbConnection();
    }

    /**
     *CRUD method to return all games.
     *
     * @param {*} callback
     * @memberof ProductDAO
     */
    public findAllGames(callback:any)
    {
        // List of games to return
        let games:Game[] = [];

        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and run query to get all games
            connection.query = util.promisify(connection.query);
            let result1 = await connection.query('SELECT * FROM GAMES');
            for(let x=0;x < result1.length;++x)
            {
                 // Use Promisfy Util to make an async function and run query to get all images for the game
                let gameId = result1[x].GAME_ID;
                let images:Images[] = [];
                let result2 = await connection.query('SELECT * FROM IMAGES WHERE GAME_ID=?', [gameId]);
                for(let y=0;y < result2.length;++y)
                {
                    images.push(new Images(result2[y].ID, result2[y].IMAGE, result2[y].GAME_ID));
                }

                // Add game and its images to the list
                games.push(new Game(result1[x].GAME_ID, result1[x].NAME, images, result1[x].description, result1[x].PRICE, result1[x].PLATFORM, result1[x].TYPE, result1[x].COUNTRY, result1[x].VERSION, result1[x].KEY)); 
            }

            // Do a callback to return the results
            callback(games);
         });
    }
    /**
     *CRUD method to find the game by name.
     *
     * @param {string} search
     * @param {*} callback
     * @memberof ProductDAO
     */
    public findGamesByName(search: string, callback: any)
    {
         // List of Games to return
         let games:Game[] = [];

        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and run query to get all Games with specific NAME
            connection.query = util.promisify(connection.query);
            let result1 = await connection.query('SELECT * FROM GAMES WHERE NAME=?', [search]);
            for(let x=0;x < result1.length;++x)
            {
                 // Use Promisfy Util to make an async function and run query to get all images for the game
                 let gameId = result1[x].GAME_ID;
                 let images:Images[] = [];
                 let result2 = await connection.query('SELECT * FROM IMAGES WHERE GAME_ID=?', [gameId]);
                 for(let y=0;y < result2.length;++y)
                 {
                     images.push(new Images(result2[y].ID, result2[y].IMAGE, result2[y].GAME_ID));
                 }

                // Add games and its images to the list
                games.push(new Game(result1[x].GAME_ID, result1[x].NAME, images, result1[x].description, result1[x].PRICE, result1[x].PLATFORM, result1[x].TYPE, result1[x].COUNTRY, result1[x].VERSION, result1[x].KEY)); 
            }

            // Do a callback to return the results
            callback(games);
         });
    }
    /**
     * CRUD method to find Images by gameId. 
     *
     * @param {number} gameId
     * @param {*} callback
     * @memberof ProductDAO
     */
    public findImagesByGameId(gameId: number, callback: any)
    {
        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and run query to get all images for the game
            connection.query = util.promisify(connection.query);
            let images:Images[] = [];
            let result2 = await connection.query('SELECT * FROM IMAGES WHERE GAME_ID=?', [gameId]);
            for(let y=0;y < result2.length;++y)
            {
                 images.push(new Images(result2[y].ID, result2[y].IMAGE, result2[y].GAME_ID));
            }

            // Do a callback to return the results
            callback(images);
         });   
    }
    /**
     *CRUD method to create a game.
     *
     * @param {Game} game
     * @param {*} callback
     * @memberof ProductDAO
     */
    public create(game: Game, callback:any)
    {
        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and insert Game
            connection.query = util.promisify(connection.query);
            let result1 = await connection.query('INSERT INTO `games`(`GAME_ID`, `NAME`, `DESCRIPTION`, `PRICE`, `PLATFORM`, `TYPE`, `COUNTRY`, `VERSION`, `KEY`) VALUES (?,?,?,?,?,?,?,?,?)', [game.GameId, game.Name, game.Description, game.Price, game.Platform, game.Type, game.Country, game.Version, game.Key]);
            if(result1.affectedRows != 1)
               callback(-1);

            // Use Promisfy Util to make an async function and run query to insert all Images for the game
            let gameId = result1.insertId;
            for(let y=0;y < game.Images.length;++y)
            {
                let result2 = await connection.query('INSERT INTO IMAGES (ID, IMAGE, GAME_ID) VALUES(?,?,?)', [game.Images[y].Id, game.Images[y].Image, gameId]);
            }

            // Do a callback to return the results
            callback(gameId);
        });
    }
    /**
     *CRUD method to update the Game.
     *
     * @param {Game} game
     * @param {*} callback
     * @memberof ProductDAO
     */
    public update(game:Game, callback: any)
    {
         // Get pooled database connection and run queries   
         this.pool.getConnection(async function(err:any, connection:any)
         {
             // Release connection in the pool
             connection.release();
 
             // Throw error if an error
            if (err) throw err;
 
             // Use Promisfy Util to make an async function and update Game
             let changes = 0;
             let gameId = game.GameId;
             connection.query = util.promisify(connection.query);
            let result1 = await connection.query('UPDATE `games` SET `GAME_ID`=?,`NAME`=?,`DESCRIPTION`=?,`PRICE`=?,`PLATFORM`=?,`TYPE`=?,`COUNTRY`=?,`VERSION`=?,`KEY`=? WHERE GAME_ID=?', [game.GameId, game.Name, game.Description, game.Price, game.Platform, game.Type, game.Country, game.Version, game.Key, game.GameId]);
            if(result1.changedRows != 0)
                ++changes;

             // Use Promisfy Util to make an async function and run query to update all Images for the Game.
             for(let y=0;y < game.Images.length;++y)
            {
                 let result2 = await connection.query('UPDATE `images` SET `ID`=?, `IMAGE`=?, `GAME_ID`=? WHERE ID=?', [game.Images[y].Id, game.Images[y].Image, game.GameId, game.Images[y].Id]);
                 if(result2.changedRows != 0)
                    ++changes;
            }
 
            // Do a callback to return the results
            callback(changes);
         });
     }

    /**
     * CRUD method to delete a Game by ID.
     * 
     * @param gameId Game ID to delete.
     * @param callback Callback function with number of rows deleted.  
     * */
    public delete(gameId:number, callback: any)
    {
        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and run query to delete the images for the game
            let changes = 0;
            connection.query = util.promisify(connection.query);
            let result1 = await connection.query('DELETE FROM IMAGES WHERE GAME_ID=?', [gameId]);
            changes = changes + result1.affectedRows;

            // Use Promisfy Util to make an async function and run query to delete the game
            let result2 = await connection.query('DELETE FROM GAMES WHERE GAME_ID=?', [gameId]);
            changes = changes + result2.affectedRows;

            // Do a callback to return the results
            callback(changes);
        });
    }

    //* **************** Private Helper Methods **************** */

    /**
     * Private helper method to initialie a Database Connection
     */
    private initDbConnection():any
    {
        return mysql.createPool({host: this.host, port: this.port, user: this.username, password: this.password, database: this.schema, connectionLimit: 10});
    }

    //* **************** Public Helper Methods **************** */

    /**
     * Returns the last game_id in the Games table.
     *
     * @param {*} callback
     * @memberof ProductDAO
     */
    public getLastGameId(callback: any)
    {
        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and run query to get the last id in the GAMES table
            connection.query = util.promisify(connection.query);
            let result = await connection.query('SELECT GAME_ID FROM GAMES ORDER BY GAME_ID DESC LIMIT 1');
            var lastId = result[0].GAME_ID;

            // Do a callback to return the results
            callback(lastId);
         });   
    }
    /**
     * Returns the last id in the Images table.
     *
     * @param {*} callback
     * @memberof ProductDAO
     */
    public getLastImageId(callback: any)
    {
        // Get pooled database connection and run queries   
        this.pool.getConnection(async function(err:any, connection:any)
        {
            // Release connection in the pool
            connection.release();

            // Throw error if an error
            if (err) throw err;

            // Use Promisfy Util to make an async function and run query to get the last id in the Images table
            connection.query = util.promisify(connection.query);
            let result = await connection.query('SELECT ID FROM IMAGES ORDER BY ID DESC LIMIT 1');
            let lastId = result[0].ID;

            // Do a callback to return the results
            callback(lastId);
         });   
    }
    
}
