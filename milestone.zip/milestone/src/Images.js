/* eslint-disable jsx-a11y/img-redundant-alt */
import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';

const Images = (props) => {
    return (
        <div className='row'>
          {props.images.map(image => {
            return (
                <div className='col-3 mt-1' key={image.imagesId}>
                    <img
                        src={image.image}
                        alt="Gallery image 1"
                        className="active w-100"
                    />
                </div>
            );
          })}
        </div>
    );
}

export default Images;