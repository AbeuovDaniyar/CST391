import React from 'react';
import SearchForm from './SearchForm';
import GameList from './GameList';
import './SearchGame.css'

const SearchGame = (props) => {
    console.log('props with single game ', props);
    
    return (
        <div className='container'>
            <div className='row'>
                <GameList gameList={props.gameList} onClick={props.updateSingleGame}/>
                <SearchForm onSubmit={props.updateSearchResults}/>
            </div>
        </div>
    );
};

export default SearchGame;