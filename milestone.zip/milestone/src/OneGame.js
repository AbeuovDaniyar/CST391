/* eslint-disable jsx-a11y/img-redundant-alt */
import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import {Typography } from '@mui/material';
import { Rating } from 'react-simple-star-rating'
import Images from './Images';
import './OneGame.css'

const OneGame = (props) => {

    return (
        <div className="container">
            <div className="d-flex flex-row">
                <div className="p-2">
                    <div className="ecommerce-gallery">
                        <div className="row py-3 shadow-5">
                          <div className="col-12 mb-1">
                            <div className="lightbox">
                              <img
                                src={props.game.images[0].image}
                                alt="Gallery image 1"
                                className="ecommerce-gallery-main-img active w-100"
                                width='250px'
                                height='auto'
                              />
                            </div>
                          </div>
                          <Images images={props.game.images} />
                        </div>
                      </div>    
                </div>
                <div className="p-2 mt-2 col-7">
                    <h3>{props.game.name}</h3>
                    <h3>
                        <Typography component="legend">Rating</Typography>
                        <Rating
                            initialValue={props.game.rating}
                            readOnly/>
                    </h3>   
                    <h5>Game Release Year: {props.game.year}</h5> 
                    <h5>Game Price: ${props.game.price}</h5>    
                    <p>{props.game.description}</p> 
                </div>  
            </div>
        </div>
    );
};

export default OneGame;