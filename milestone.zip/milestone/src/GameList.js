import React from 'react';
import Card from './Card';
import {useNavigate} from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.css';
import './GameList.css';

const GameList = (props) => {

    const handleSelectionOne = (gameId, uri) => {
        console.log('Selected ID is ' + gameId);
        props.onClick(gameId, navigator, uri);
    };

    console.log('props gameList ', props);
    const navigator = useNavigate();
    const games = props.gameList.map((game) => {
        return (
            <Card 
            key = {game.gamesId}
            gameId = {game.gamesId}
            gameName={game.name}
            price={game.price}
            description={game.description}
            rating={game.rating}
            imageUrl={game.images[0].image}
            buttonText='View'
            onClick={handleSelectionOne}
            />
        );
    });

    return(
        <div className='col-9'>
            <div class="container-games">
                {games}
            </div>
        </div>
    );
}

export default GameList;