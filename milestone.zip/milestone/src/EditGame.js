import React, {useState} from "react";
import dataSource from "./dataSource";
import { useNavigate } from "react-router-dom";

const EditGame = (props) => {
        let game = {
                name: '',
                price: 0,
                description: '',
                year: '',
                rating: '',
                images: [],
                imagesRaw: ''
        };
        let newGameCreation = true;

        if(props.game){
                game = props.game;
                newGameCreation = false;
                game.imagesRaw = '';

                for(let i = 0; i < game.images.length; i++){
                    let image = game.images[i].image;
                    game.imagesRaw = game.imagesRaw + image + '\n';
                }
                console.log(game);
        }
        
        const [name, setGameName] = useState(game.name);
        const [price, setGamePrice] = useState(game.price);
        const [description, setGameDescription] = useState(game.description);
        const [year, setGameYear] = useState(game.year);
        const [rating, setGameRating] = useState(game.rating);
        const [images, setGameImages] = useState(game.images);
        const [imagesRaw, setGameImagesRaw] = useState(game.imagesRaw);
        const navigate = useNavigate();

        const updateName = (event) => {
            setGameName(event.target.value);
        };
        const updatePrice = (event) => {
            setGamePrice(event.target.value);
        };
        const updateDescription = (event) => {
            setGameDescription(event.target.value);
        };
        const updateYear = (event) => {
            setGameYear(event.target.value);
        };
        const updateRating = (event) => {
            setGameRating(event.target.value);
        };
        const updateImagesRaw = (event) => {
            let imageArray = [];
            let imagesAll = event.target.value.split('\n');
            
            console.log(imagesAll);
            
            for(let i = 0; i < imagesAll.length; i++){
                let image = imagesAll[i];
                imageArray.push({
                    imagesId: Math.floor(Math.random() * 1000000),
                    image: image
                });
            }

            setGameImagesRaw(event.target.value);

            setGameImages(imageArray);
        };

        const handleFormSubmit = (event) => {
                event.preventDefault();

                console.log("submit");
                const editedGame = {
                        gamesId: game.gamesId,
                        name: name,
                        price: price,
                        description: description,
                        year: year,
                        rating: rating,
                        images: images,
                };
                console.log(editedGame);
                saveGame(editedGame);
        };

        const saveGame = async (game) => {
                let response;

                if(newGameCreation){
                    response = await dataSource.post('/games', game);
                }
                else
                    response = await dataSource.put('/games', game);
                console.log(response);
                console.log(response.data);
                props.onEditGame(navigate);
        };

        const handleDelete = (event) => {
            event.preventDefault();

            console.log("submit");
            const gameId = game.gamesId;
            console.log(gameId);
            deleteGame(gameId);
        };

        const deleteGame = async (gameId) => {
            let response;
            
            console.log('id to delete ', gameId);

            if(newGameCreation){
                
            }
            else
                response = await dataSource.delete('/games/' + gameId);
            console.log(response);
            console.log(response.data);
            props.onEditGame(navigate);
    };

        const handleCancel = () => {
                navigate("/");
        };

        return (
                <div className="container" style={{width: "100%"}}>
                    <form onSubmit={handleFormSubmit} style={{width: "100%"}}>
                        <div class="form-group w-25" style={{width: "auto"}}>
                            <label htmlFor="name">Name</label>
                            <input id="name" type="text" class="form-control" aria-describedby="helpName" placeholder="Enter the name of the Game" required  name="name" onChange={updateName} value={name} />           
                        </div> 
                        <div class="form-group w-25 " style={{width: "100%"}}>
                            <label htmlFor="year">Year</label>
                            <input id="year" type="text" class="form-control" aria-describedby="helpYear" placeholder="Enter the release year of the Game" required  name="year" onChange={updateYear} value={year} />
                        </div>
                        <div class="form-group w-25" style={{width: "100%"}}>
                            <label htmlFor="price">Price</label>
                            <input id="price" type="text" class="form-control" aria-describedby="helpPrice" placeholder="Enter the price of the Game" required  name="price" onChange={updatePrice} value={price} />
                        </div>
                        <div class="form-group w-25" style={{width: "100%"}}>
                            <label htmlFor="rating">Rating</label>
                            <input id="rating" type="text" class="form-control" aria-describedby="helpRating" placeholder="Enter the rating number for the Game" name="rating" onChange={updateRating} value={rating} />
                        </div>
                        <div class="form-group w-50" style={{width: "100%"}}>
                            <label htmlFor="description">Description</label>
                            <textarea id="description" rows="3" class="form-control" aria-describedby="helpDescription" placeholder="Enter the description of the Game" required name="description" onChange={updateDescription} value={description}></textarea>
                        </div>
                        <div class="form-group w-50" style={{width: "100%"}}>
                            <label htmlFor="images">Images</label>
                            <textarea id="images" rows="3" class="form-control" aria-describedby="helpImages" placeholder="Enter each image followed by a return key for the Game" name="images" onChange={updateImagesRaw} value={imagesRaw}></textarea>
                        </div>
                        <br/>
                        <button type="submit" className="btn btn-light" onClick={handleCancel}>Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>   
                        <button type="submit" className="btn btn-danger" onClick={handleDelete}>Delete</button>                           
                    </form>
                </div>
        );
};

export default EditGame;