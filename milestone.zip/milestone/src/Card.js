import React from 'react'
import { IconButton } from '@mui/material';
import { Rating } from 'react-simple-star-rating'
import EditIcon from '@mui/icons-material/Edit';
import './Card.css';

const Card = (props) => {
    const handleButtonClick = (event, uri) => {
        console.log('ID clicked ' + props.gameId);
        props.onClick(props.gameId, uri);
    };

    return (            
        <div className="card">
            <img src={props.imageUrl} className='card-img-top' alt="title" width="250px" height="auto"/>
            <div className="card-body">
              <h5 className="card-title">{props.gameName}</h5>
              <p>
                <Rating
                    name="read-only"
                    initialValue={props.rating}
                    size="15px"
                    readOnly />
              </p>  
              <p className="card-text">${props.price}</p>
              <div className="row">
                <div className="col-6">
                <button onClick={() => handleButtonClick(props.gameId, '/show/')} className='btn btn-primary'>
                    {props.buttonText}
                </button>
                </div>
                <div className="col-6">
                    <div className='icons'>
                        <IconButton size="small" icon="edit" onClick={() => handleButtonClick(props.gameId, '/edit/')} ><EditIcon /></IconButton>
                    </div>
                </div>
              </div>  
            </div>
        </div>
    );
}

export default Card;