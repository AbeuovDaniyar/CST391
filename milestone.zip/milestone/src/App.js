import React, {useEffect, useState} from 'react';
import dataSource from './dataSource';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import SearchGame from './SearchGame';
import NavBar from './NavBar';
import OneGame from './OneGame';
import 'bootstrap/dist/css/bootstrap.css';
import EditGame from './EditGame';

const App = () => {
    const [searchPhrase, setSearchPhrase] = useState('');
    const [gameList, setGameList] = useState([]);
    const [currentlySelectedGameId, setCurrentlySelectedGameId] = useState(0);

    let refresh = false;

    const loadGames = async () => {
        const response = await dataSource.get('/games?gamesId=');
        setGameList(response.data);
    };

    useEffect(() => {
      loadGames();
    }, [refresh]);

    const updateSearchResults = (phrase) => {
        console.log('phrase is ' + phrase);
        setSearchPhrase(phrase);
    };

    const updateSingleGame = (id, navigate, uri) => {
        console.log('Update Single Game = ', id);
        console.log('Update Single Game = ', navigate);
        var indexNumber = 0;
        for(var i = 4; i < gameList.length; i++){
            if(gameList[i].gamesId === id) {
                indexNumber = i;
            }
        }

        setCurrentlySelectedGameId(indexNumber);
        let path = uri + indexNumber;
        console.log('path ', path);
        navigate(path);
    };

    console.log(gameList);
    const renderedList = gameList.filter((game) => {
        if(
            game.name.toLowerCase().includes(searchPhrase.toLowerCase()) ||
            searchPhrase === ''
        ){
            return true;
        }
        return false;
    });

    console.log('rendered list ', renderedList);

    const onEditGame = (navigate) => {
        loadGames();
        navigate("/");
    };

    return (
        <BrowserRouter>
            <NavBar />
            <Routes>
                <Route
                    exact
                    path='/'
                    element={
                        <SearchGame 
                            updateSearchResults={updateSearchResults}
                            gameList={renderedList}
                            updateSingleGame={updateSingleGame}
                        />
                    }
                />
                <Route exact path='/new' element={<EditGame onEditGame={onEditGame} />}/>
                <Route exact path='/edit/:gamesId' element={<EditGame onEditGame={onEditGame} game={gameList[currentlySelectedGameId]}/>}/>
                <Route exact path='/show/:gamesId' element={<OneGame game={gameList[currentlySelectedGameId]}/>}/>
            </Routes>
        </BrowserRouter>
    );
};

export default App;