import { Component, Input, OnInit } from '@angular/core';
import { GameName } from '../models/GameName.model';
import { Games } from '../models/games.model';
import { ProductServiceService } from '../service/product-service.service';

@Component({
  selector: 'app-list-games',
  templateUrl: './list-games.component.html',
  styleUrls: ['./list-games.component.css']
})
export class ListGamesComponent implements OnInit {
  @Input() name: GameName = {name: ""};
  selectedGame: Games | null = null
  games: Games[] = [];
  gameImage: any;
  currRating: number = 0;;

  constructor(private service: ProductServiceService) {}

  ngOnInit(){
    this.service.getGames((games: Games[]) => this.games = games);
  }

  public onSelectGame(game: Games)  
  {
    this.selectedGame = game;
  }

  onClickSubmit(event: any)
  {
    console.log("You have entered : " + event.target.value);
    if(event.target.value){
      this.service.getGamesByName(event.target.value, (games: Games[]) => this.games = games);
    }else{
      this.service.getGames((games: Games[]) => this.games = games);
    }
  }

}
