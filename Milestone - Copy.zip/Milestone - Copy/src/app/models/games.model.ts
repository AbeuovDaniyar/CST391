import { Images } from './images.model';

export interface Games {
    gamesId: number,
    name: string,
    description: string,
    year: string,
    price: number,
    rating: number,
    images: Images[]
}