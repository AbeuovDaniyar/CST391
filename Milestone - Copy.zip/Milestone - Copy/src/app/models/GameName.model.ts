export interface GameName {
    name: string;
}