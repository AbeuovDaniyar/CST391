export interface Images {
    imagesId: number,
    image: string
}