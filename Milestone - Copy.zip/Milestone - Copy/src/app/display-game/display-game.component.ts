import { Component, Input, OnInit } from '@angular/core';
import { Games } from '../models/games.model';

@Component({
  selector: 'app-display-game',
  templateUrl: './display-game.component.html',
  styleUrls: ['./display-game.component.css']
})
export class DisplayGameComponent implements OnInit {
  @Input() game!: Games;
  currentRate: number = 0;

  isCollapsed: boolean = false;
  constructor() { }

  ngOnInit(){  
    this.currentRate = this.game.rating; 
  }

}
