import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Games } from '../models/games.model';
import { ProductServiceService } from '../service/product-service.service';

@Component({
  selector: 'app-delete-game',
  templateUrl: './delete-game.component.html',
  styleUrls: ['./delete-game.component.css']
})
export class DeleteGameComponent implements OnInit {
  public gamesId: string | null = "";
  response: any;
  constructor(private service: ProductServiceService, private route: ActivatedRoute) {
  }

  ngOnInit(): void {
    let status: string | null = null;
    this.gamesId = this.route.snapshot.paramMap.get('id');
    
    if(this.gamesId != null){
      this.service.deleteGames(parseInt(this.gamesId), () => status);
    }
    console.log("game Id: ", this.gamesId);
    console.log("status: ", status);
  }
}
