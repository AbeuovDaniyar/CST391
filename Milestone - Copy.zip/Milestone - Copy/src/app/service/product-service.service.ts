import { Injectable } from '@angular/core';
import { Games } from './../models/games.model';
import { Images } from '../models/images.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  private host = "http://localhost:3000";

  constructor(private http: HttpClient) {}

  public getGames(callback: (games: Games[]) => void): void {
    this.http.get<Games[]>(this.host + "/games").
      subscribe((games: Games[]) => {
        callback(games);
      });
  }

  public getGamesById(gamesId: number, callback: (game: Games[]) => void): void {
    this.http.get<Games[]>(this.host + `/games/?gamesId=${gamesId}`).
      subscribe((game: Games[]) => {
        callback(game);
      });
  }

  public getGamesByName(name: String, callback: (games: Games[]) => void): void{
    let request = this.host + `/games/search/name/${name}`;
    console.log('request', request);

    this.http.get<Games[]>(request).
      subscribe((games: Games[]) => {
        console.log('have games ', games);
        callback(games);
      });
  }

  public getImagesById(gameId: number, callback: (images: Images[]) => void): void{
    let request = this.host + `/games/${gameId}`;
    console.log('request', request);

    this.http.get<Images[]>(request).
      subscribe((images: Images[]) => {
        console.log('have games ', images);
        callback(images);
      });
  }

  public createGames(games: Games, callback: () => void): void {
    this.http.post<Games>(this.host + "/games", games).
      subscribe((data) => {
        callback();
      });
  }

  public updateGames(games: Games, callback: () => void): void {
    this.http.put<Games>(this.host + "/games", games).
      subscribe((data) => {
        callback();
      });
  }

  public deleteGames(id: number, callback: () => void): void {
    this.http.delete(this.host + `/games/${id}`).
      subscribe((data) => {
        callback();
      });
  }

  public getLastGameId(callback: (gameId: any) => void): void{
    let request = this.host + `/games_lastId`;
    console.log('request', request);

    this.http.get<any>(request).
      subscribe((lastid: any) => {
        console.log('last gameId: ', lastid);
        callback(lastid);
      });
  }

  public getLastImageId(callback: (imageId: any) => void): void{
    let request = this.host + `/games_lastId`;
    console.log('request', request);

    this.http.get<any>(request).
      subscribe((imageId: any) => {
        console.log('last gameId: ', imageId);
        callback(imageId);
      });
  }
}
