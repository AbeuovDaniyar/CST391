import { Component, OnInit } from '@angular/core';
import { Games } from '../models/games.model';
import { Images } from '../models/images.model';
import { ProductServiceService } from '../service/product-service.service';

@Component({
  selector: 'app-create-game',
  templateUrl: './create-game.component.html',
  styleUrls: ['./create-game.component.css']
})
export class CreateGameComponent implements OnInit {

  game: Games = {
    gamesId: Math.floor(Math.random() * 1000000),
    name: "",
    description: "",
    year: "",
    price: 0.00,
    rating: 0,
    images: []
  }

  imagesRaw: string = "";
  wasSubmitted: boolean = false;
  
  constructor(private service: ProductServiceService) { }

  ngOnInit(): void {
  }

  public onSubmit() {
    // Parse the Images and add to the Game then call the Service to create the new Game
    let images: Images[] = [];
    let imagesAll = this.imagesRaw.split('\n');
    console.log(imagesAll);
    for (let i = 0; i < imagesAll.length; ++i) {
      let image = imagesAll[i];
      images.push(
        { imagesId: Math.floor(Math.random() * 1000000), image }
      );
    }
    this.game.images = images;
    console.log(this.game);
    let status: string | null = null;
    this.service.createGames(this!.game, () => status);
    console.log("The return from createGames() was " + status);
    this.wasSubmitted = true;
  }

}
