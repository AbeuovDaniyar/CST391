import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Games } from '../models/games.model';
import { Images } from '../models/images.model';
import { ProductServiceService } from '../service/product-service.service';

@Component({
  selector: 'app-edit-game',
  templateUrl: './edit-game.component.html',
  styleUrls: ['./edit-game.component.css']
})
export class EditGameComponent {
  game: Games = {
    gamesId: Math.floor(Math.random() * 1000000),
    name: "",
    description: "",
    year: "",
    price: 0.00,
    rating: 0,
    images: []
  };

  imagesRaw: string = "";
  wasSubmitted: boolean = false;
  images: Images[] = [];

  public gamesId: string | null = "";
  response: any;
  constructor(private service: ProductServiceService, private route: ActivatedRoute) {
   }

  ngOnInit() {
    this.gamesId = this.route.snapshot.paramMap.get('id');
    
    if(this.gamesId != null){
      this.service.getGamesById(parseInt(this.gamesId), (game: Games[]) => this.game = game[0]);
    }
    this.images = this.game.images;
    console.log("game Id: ", this.gamesId);
    console.log("images: ", this.images);
  }

  onUpdate(){
    // Parse the Images and add to the Game then call the Service to create the new Game
    let images: Images[] = [];
    let imagesAll = this.imagesRaw.split('\n');
    console.log(imagesAll);
    for (let i = 0; i < this.imagesRaw.length; ++i) {
      let image = imagesAll[i];
      images.push(
        { imagesId: Math.floor(Math.random() * 1000000), image }
      );
    }
    this.game.images = images;
    console.log(this.game);
    let status: string | null = null;
    this.service.updateGames(this!.game, () => status);
    console.log("The return from createGames() was " + status);
    this.wasSubmitted = true;
  }

}
