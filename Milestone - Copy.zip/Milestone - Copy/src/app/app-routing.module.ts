import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateGameComponent } from './create-game/create-game.component';
import { DeleteGameComponent } from './delete-game/delete-game.component';
import { DisplayGameComponent } from './display-game/display-game.component';
import { EditGameComponent } from './edit-game/edit-game.component';
import { ListGamesComponent } from './list-games/list-games.component';

const routes: Routes = [
  { path: 'create', component: CreateGameComponent },  
  { path: 'list-games', component: ListGamesComponent },    
  { path: 'display/:id', component: DisplayGameComponent },  
  { path: 'edit/:id', component: EditGameComponent },  
  { path: 'delete/:id', component: DeleteGameComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
